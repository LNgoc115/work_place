package com.example.addressbook;

import org.junit.Test;

public class TestTest {

	@Test
	public void test() {
		// fail("test");
	}

}
