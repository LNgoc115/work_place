package com.example.addressbook.services;

public interface IAddressChangeListener {

	void addressesChanged();

}